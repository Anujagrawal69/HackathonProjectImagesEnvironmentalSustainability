import { LightningElement, api } from 'lwc';
import deleteCase from '@salesforce/apex/CustomCase2.deleteCase';
import {NavigationMixin} from 'lightning/navigation';
import {ShowToastEvent} from 'lightning/platformShowToastEvent';

const sleep = (ms) => {
    return new Promise(resolve => setTimeout(resolve, ms));
};

export default class CaseItem extends NavigationMixin(LightningElement) {
    @api case1;

    showFlow = false;

    async handleDeleteCaseButton(){
        try{
            const message = await deleteCase({recId: this.case1.Id});
            console.log(message);

            const toast = new ShowToastEvent({
            title: 'Case Deleted Successfully.',
            message: 'Please wait a few seconds, your page will get refreshed.',
            variant: 'info',
        });
        this.dispatchEvent(toast);
        await sleep(1000);

        const completeToast = new ShowToastEvent({
            title: 'Success',
            message: 'The next statement has executed.',
            variant: 'success',
        });
        this.dispatchEvent(completeToast);
            window.location.href = 'https://orgfarm-02301e9a6b-dev-ed.develop.my.site.com/s/my-cases-';
        } catch(error){
            console.log(error); 
        }
    }
}