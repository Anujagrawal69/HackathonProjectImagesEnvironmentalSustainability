import { LightningElement, api, wire } from 'lwc';
import getEnvProgramById from '@salesforce/apex/EnvProgram.getEnvProgramById';
import getRelatedDrivesByProgId from '@salesforce/apex/EnvProgram.getRelatedDrivesByProgId';

export default class ProgramRecordPageComp1 extends LightningElement {
    @api recordId;
    @wire(getEnvProgramById, {recId: '$recordId'}) envProgram;
    @wire(getRelatedDrivesByProgId, {recId: '$recordId'}) relatedDrives;
    
    showDrives = false;

    connectedCallback(){
         const urlPath = window.location.pathname;
        if (urlPath) {
            const parts = urlPath.split('/');
            if (parts.length >= 5) {
                this.recordId = parts[3];
            }
        }
        console.log(`Program Record id:  ${this.recordId}`);
    }

    showDriveLabel = 'Show Drives';

    toggleShowDrives(){
        this.showDrives = this.showDrives?false:true;
        if(this.showDriveLabel == 'Show Drives'){
            this.showDriveLabel = 'Hide Drives';
        } else {
            this.showDriveLabel = 'Show Drives';
    }
}
}