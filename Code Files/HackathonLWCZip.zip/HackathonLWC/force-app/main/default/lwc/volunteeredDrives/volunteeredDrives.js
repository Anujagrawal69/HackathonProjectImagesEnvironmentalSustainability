import { LightningElement, wire, api } from 'lwc';
import getVolunteeredDrives from '@salesforce/apex/Volunteer.getVolunteeredDrives';
import isGuestUser from '@salesforce/apex/EnvProgram.isGuestUser';

export default class VolunteeredDrives extends LightningElement {
    @wire(getVolunteeredDrives) drives;

    @api isGuest;
            @wire(isGuestUser)
            wiredGuestUser({ error, data }) {
                if (data !== undefined) {
                    this.isGuest = data;
                } else if (error) {
                    console.error('Error checking guest user', error);
                    this.isGuest = true;
                }
            }
}