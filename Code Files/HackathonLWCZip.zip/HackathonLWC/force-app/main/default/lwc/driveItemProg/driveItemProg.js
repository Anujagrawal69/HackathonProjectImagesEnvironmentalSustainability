import { LightningElement, api } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';

export default class DriveItemProg extends NavigationMixin(LightningElement) {
    @api drive;

    handleView(){
        let name1=this.drive?.Name;
        name1=name1.toLowerCase();
        name1=name1.replace(/ /g, '-');
        window.location.href = `https://orgfarm-02301e9a6b-dev-ed.develop.my.site.com/s/detail/${this.drive?.Id}`;
    }
}