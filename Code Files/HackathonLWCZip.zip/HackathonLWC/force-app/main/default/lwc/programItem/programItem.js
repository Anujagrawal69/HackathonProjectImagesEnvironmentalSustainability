import { LightningElement, api} from 'lwc';
import { NavigationMixin } from 'lightning/navigation';


export default class ProgramItem extends NavigationMixin(LightningElement) {
    @api envProgram;

    // isGuest = false;

    get isGuest() {
        return this.envProgram.program?.Name == 'Guest';
    }

    handleView(){
        let name1=this.envProgram.program?.Name;
        name1=name1.toLowerCase();
        name1=name1.replace(/ /g, '-');
        window.location.href = `https://orgfarm-02301e9a6b-dev-ed.develop.my.site.com/s/environmental-programme/${this.envProgram.program?.Id}/${name1}`;
    }       

    handleLogin(){
        window.location.href = '/s/login/';
    }
}


