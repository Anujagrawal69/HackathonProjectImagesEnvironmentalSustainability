import { LightningElement, wire, track } from 'lwc';
import getDriveList from '@salesforce/apex/Drive.getDriveList';
import DRIVE_OBJECT from '@salesforce/schema/Drive__c';
import DRIVE_TYPE_FIELD from '@salesforce/schema/Drive__c.Drive_Type__c';
import { getObjectInfo, getPicklistValues } from 'lightning/uiObjectInfoApi';
import getTotalDrives from '@salesforce/apex/Drive.getTotalDrives';

export default class DriveList extends LightningElement {
    searchInput = '';
    currentDriveType = '';
    delayTimeout;

    @wire(getDriveList, {name: '$searchInput', driveType: '$currentDriveType'})
    drives;

    searchHandler(event){
        clearTimeout(this.delayTimeout);
        const val = event.target.value;
        this.delayTimeout = setTimeout(()=>{
            this.searchInput = val;
        },300)
    }
    
    @wire(getObjectInfo, {objectApiName: DRIVE_OBJECT}) driveInfo;
    
    @wire(getPicklistValues, {recordTypeId: '$driveInfo.data.defaultRecordTypeId', 
        fieldApiName: DRIVE_TYPE_FIELD
    })
    wiredDriveTypeValues({data, error}){
        if(data){
            const allOption = {label: 'All', value: ''}
            
            const options = data.values.map(plValue=>{
                return {label: plValue.label, value: plValue.value};
            });
            
            this.driveTypeOptions = [allOption, ...options];
        } else if(error){
            console.error('Error loading status picklist: ', error);
        }
    }

    @track driveTypeOptions = [];

    driveTypeHandler(event){
        this.currentDriveType = event.detail.value;
    }

    @wire(getTotalDrives, {driveType:'$currentDriveType'}) totalDrives;

    get titleName() {
        if (this.totalDrives.data) {
            return `All Drives (${this.totalDrives.data})`;
        }
        return 'All Drives (...)';
    }
}
