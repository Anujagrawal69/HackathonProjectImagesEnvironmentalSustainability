import { LightningElement, wire, track, api } from 'lwc';
import getCases from '@salesforce/apex/CustomCase.getCases';
import CASE_OBJECT from '@salesforce/schema/Case';
import STATUS_FIELD from '@salesforce/schema/Case.Status';
import { getObjectInfo, getPicklistValues } from 'lightning/uiObjectInfoApi';
import isGuestUser from '@salesforce/apex/EnvProgram.isGuestUser';


export default class CaseList extends LightningElement {
    @wire(getCases, {status: '$currentStatus'}) caseList;
    currentStatus = '';
    delayTimeout;
    raiseComplaintButtonLabel = 'Raise a complaint';
    
    @wire(getObjectInfo, {objectApiName: CASE_OBJECT}) caseInfo;
        
    @wire(getPicklistValues, {recordTypeId: '$caseInfo.data.defaultRecordTypeId', 
        fieldApiName: STATUS_FIELD
    })
    wiredStatusValues({data, error}){
        if(data){
            const allOption = {label: 'All', value: ''}
            const options = data.values.map(plValue=>{
                return {label: plValue.label, value: plValue.value};
            });
            this.statusOptions = [allOption, ...options];
        } else if(error){
                console.error('Error loading status picklist: ', error);
        }
    }
    
    @track statusOptions = [];
    
    statusHandler(event){
        this.currentStatus = event.detail.value;
    }

    showFlow = false;

    handleComplaintButton(){
        if(this.showFlow){
            this.raiseComplaintButtonLabel = 'Raise a complaint';
            this.showFlow = false;
        } else {
            this.raiseComplaintButtonLabel = 'Close complaint';
            this.showFlow = true;
        }
    }

    handleStatusChange(event) {
        console.log('Flow status:', event.detail.status);
        if (event.detail.status === 'FINISHED') {
            this.showFlow = false;
           window.location.href = `https://orgfarm-02301e9a6b-dev-ed.develop.my.site.com/s/my-cases-`;

        }
    }

    stopPropagation(event) {
        event.stopPropagation();
    }

    @api isGuest;
        @wire(isGuestUser)
        wiredGuestUser({ error, data }) {
            if (data !== undefined) {
                this.isGuest = data;
            } else if (error) {
                console.error('Error checking guest user', error);
                this.isGuest = true; // Default to guest if there's an error
            }
        }

}