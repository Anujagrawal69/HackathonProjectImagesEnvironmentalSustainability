import { LightningElement, api, wire } from 'lwc';
import getDriveById from '@salesforce/apex/Drive.getDriveById';

export default class DriveRecordPageComp1 extends LightningElement {
    @api recordId;
    @wire(getDriveById, {recId: '$recordId'}) drive;
    showFlow = false;
    
    connectedCallback(){
        const urlPath = window.location.pathname;
        if (urlPath) {
            const parts = urlPath.split('/');
            if (parts.length >= 5) {
                this.recordId = parts[3];
            }
        }
        console.log(`Drive Record id:  ${this.recordId}`);
    }

    get inputVariables() {
    return [
        {
            name: 'recordId',
            type: 'String',
            value: this.recordId
        }
    ];
}
    handleVolunteerClick() {
        this.showFlow = true;  
    }
   
    handleFlowStatusChange(event) {
        const status = event.detail.status;
        if (status === 'FINISHED' || status === 'FINISHED_SCREEN') {
            this.showFlow = false;
        }
    }
}