import { LightningElement, api } from 'lwc';
import { NavigationMixin } from 'lightning/navigation'; 

export default class VolunteeredDriveComp extends NavigationMixin(LightningElement) {
    @api wrap;

    handleView(){
        let name1=this.wrap.driveRecord?.Name; 
        name1=name1.toLowerCase();
        name1=name1.replace(/ /g, '-');
        const finalURL = `https://orgfarm-02301e9a6b-dev-ed.develop.my.site.com/s/drive/${this.wrap.driveRecord?.Id}/${name1}`;
        const pageref = {
            type: 'standard__webPage',
            attributes: {
                url: finalURL
            }
        };

        this[NavigationMixin.Navigate](pageref);
    }
}