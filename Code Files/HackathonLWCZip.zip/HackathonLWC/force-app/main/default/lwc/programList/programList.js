import { LightningElement, wire, track } from 'lwc';
import getEnvProgramList from '@salesforce/apex/EnvProgram.getEnvProgramList';
import PROGRAM_OBJECT from '@salesforce/schema/Environmental_Programme__c';
import STATUS_FIELD from '@salesforce/schema/Environmental_Programme__c.Status__c';
import { getObjectInfo, getPicklistValues } from 'lightning/uiObjectInfoApi';
import getTotalPrograms from '@salesforce/apex/EnvProgram.getTotalPrograms';
 
export default class ProgramList extends LightningElement {
    searchInput = '';
    currentStatus = '';
    delayTimeout;
    
    @track statusOptions = [];
 
    @wire(getEnvProgramList, { name: '$searchInput', status: '$currentStatus' })
    envPrograms;
 
    searchHandler(event) {
        clearTimeout(this.delayTimeout);
        const val = event.target.value;
        this.delayTimeout = setTimeout(() => {
            this.searchInput = val;
        }, 300);
    }
 
    @wire(getObjectInfo, { objectApiName: PROGRAM_OBJECT })
    programInfo;
 
    @wire(getPicklistValues, {
        recordTypeId: '$programInfo.data.defaultRecordTypeId',
        fieldApiName: STATUS_FIELD
    })
    wiredStatusValues({ data, error }) {
        if (data) {
            const allOption = { label: 'All', value: '' };
            const options = data.values.map(pl => ({ label: pl.label, value: pl.value }));
            this.statusOptions = [allOption, ...options];
        } else if (error) {
            console.error('Error loading status picklist:', error);
        }
    }
 
    statusHandler(event) {
        this.currentStatus = event.detail.value;
    }

    @wire(getTotalPrograms, {programStatus: '$currentStatus'}) totalPrograms;

    get programTitle() {
        if (this.totalPrograms.data !== undefined && this.totalPrograms.data !== null) {
            return `All Environmental Programs (${this.totalPrograms.data})`;
        }
        
        return 'All Environmental Programs (...)';
    }
}