import { LightningElement, api, wire } from 'lwc';
import isGuestUser from '@salesforce/apex/EnvProgram.isGuestUser';

export default class HomePage extends LightningElement {

    showFlow = false;
    raiseComplaintButtonLabel = 'Raise A Complaint';

    handleComplaintButton(){
        if(this.showFlow){
            this.raiseComplaintButtonLabel = 'Raise A Complaint';
            this.showFlow = false;
        } else {
            this.raiseComplaintButtonLabel = 'Close Complaint';
            this.showFlow = true;
        }
    }

    handleStatusChange(event) {
        console.log('Flow status:', event.detail.status);
        if (event.detail.status === 'FINISHED') {
            this.showFlow = false;
           window.location.href = `https://orgfarm-02301e9a6b-dev-ed.develop.my.site.com/s/my-cases-`;

        }
    }

    stopPropagation(event) {
        event.stopPropagation();
    }
    
    @api isGuest;
    @wire(isGuestUser)
    wiredGuestUser({ error, data }) {
        if (data !== undefined) {
            this.isGuest = data;
        } else if (error) {
            console.error('Error checking guest user', error);
            this.isGuest = true; // Default to guest if there's an error
        }
    }
}